package com.sbi.layer3;

import java.util.List;

import com.sbi.layer2.Transaction;

public interface TransactionDAO {
	
	List<Transaction> findAllTransactionsOfOneAccount(double accountNumber);

}
