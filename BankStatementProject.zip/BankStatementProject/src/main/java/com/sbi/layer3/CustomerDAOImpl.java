package com.sbi.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.sbi.layer2.Account;
import com.sbi.layer2.Customer;
import com.sbi.layer2.Transaction;


public class CustomerDAOImpl implements CustomerDAO {
	
	EntityManager entityManager;


	public List<Account> findAllAccountsOfOneCustomer(double customerID) {
		
		Query query = entityManager.createNativeQuery("select * from Transaction where accountNumber="+customerID,Account.class);
		List<Account> accountList= query.getResultList();
		return accountList;	
	
	}

	public Customer getCustomerDetails(double customerID) {
		
		return entityManager.find(Customer.class,customerID);
	}

}
