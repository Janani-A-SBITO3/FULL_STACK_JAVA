package com.sbi.layer3;

import java.util.List;

import com.sbi.layer2.Account;
import com.sbi.layer2.Customer;

public interface CustomerDAO {

	List<Account> findAllAccountsOfOneCustomer(double customerID);   //Retrieves all account numbers of one CIF
	
	Customer getCustomerDetails(double customerID); //Retrieves logged in customer Details
}
