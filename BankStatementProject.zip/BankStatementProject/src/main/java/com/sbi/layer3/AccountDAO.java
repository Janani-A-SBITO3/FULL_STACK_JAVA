package com.sbi.layer3;

import java.util.List;

import com.sbi.layer2.Account;

public interface AccountDAO {
	
	

}
