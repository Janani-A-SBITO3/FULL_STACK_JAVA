package com.sbi.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.sbi.layer2.Transaction;


public class TransactionDAOImpl implements TransactionDAO{
	
	EntityManager entityManager;

	public List<Transaction> findAllTransactionsOfOneAccount(double accountNumber) {
		
		Query query = entityManager.createNativeQuery("select * from Transaction where accountNumber="+accountNumber,Transaction.class);
		List<Transaction> txnList= query.getResultList();
		return txnList;
	}

		
}
