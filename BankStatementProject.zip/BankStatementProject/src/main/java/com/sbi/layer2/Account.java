package com.sbi.layer2;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Account {
	
	@Id
	@GeneratedValue
	private double accountNumber;
	
	private String accountType;
	private String branchName;
	private double accountBalance;
	
	
	public double getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(double accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	

}
