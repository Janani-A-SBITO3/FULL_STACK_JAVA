package com.sbi.layer2;

import java.sql.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Transaction {
	
	@Id
	@GeneratedValue
	private double transactionNumber;
	
	private double accountNumber;
	private Date dateOfTxn;
	private String txnType;
	private double txnBalance;
	private String narration;
	
	public double getTransactionNumber() {
		return transactionNumber;
	}
	public void setTransactionNumber(double transactionNumber) {
		this.transactionNumber = transactionNumber;
	}
	public double getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(double accountNumber) {
		this.accountNumber = accountNumber;
	}
	public Date getDateOfTxn() {
		return dateOfTxn;
	}
	public void setDateOfTxn(Date dateOfTxn) {
		this.dateOfTxn = dateOfTxn;
	}
	public String getTxnType() {
		return txnType;
	}
	public void setTxnType(String txnType) {
		this.txnType = txnType;
	}
	public double getTxnBalance() {
		return txnBalance;
	}
	public void setTxnBalance(double txnBalance) {
		this.txnBalance = txnBalance;
	}
	public String getNarration() {
		return narration;
	}
	public void setNarration(String narration) {
		this.narration = narration;
	}
	
	
	

}
